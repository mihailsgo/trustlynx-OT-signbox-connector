csui.require.config({
  bundles: {
'dmss/bundles/dmss-all': [

]
  }
});