define(function () {
  'use strict';

  return {
    otherToolbar: [
      {
        signature: 'dmssSign',
        name: 'Sign'
      },
      {
        signature: 'dmssSign',
        name: 'Share',
      },
      {
        signature: 'dmssSign',
        name: 'Sign or share as ASICE'
      }
    ]
  };

});
