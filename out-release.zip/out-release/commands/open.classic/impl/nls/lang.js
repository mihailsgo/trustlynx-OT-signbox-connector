csui.define({
  "root": true,
  "lv": true,
  // Do not load English locale bundle provided by the root bundle
  "en-us": false,
  "en": false
});
